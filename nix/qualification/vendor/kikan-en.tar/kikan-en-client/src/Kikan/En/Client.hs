-- | HTTP client plus mandatory local verification for issued action proofs.
module Kikan.En.Client
  ( KikanEnClient,
    ActionProofVerifier,
    newKikanEnClient,
    newActionProofVerifier,
    authorizeAgentAction,
    verifyIssuedAction,
  )
where

import Data.Aeson qualified as Aeson
import Data.ByteString (ByteString)
import Data.Generics.Labels ()
import Data.Set (Set)
import Data.Set qualified as Set
import Data.Text (Text)
import Data.Text qualified as Text
import Data.Text.Encoding (encodeUtf8)
import Data.Time (UTCTime, getCurrentTime)
import En.Biscuit.Grant (Audience (..), RequestId (..))
import En.Biscuit.Keys (IssuerKeySet)
import En.Biscuit.Verify
  ( EnBiscuitVerifyError (..),
    VerifiedGrant (..),
    VerifyRequest (..),
    verifyGrant,
  )
import En.Revision qualified as En
import En.Schema (ObjectType (..), RelationName (..))
import En.Tuple (ObjectRef (..), Subject (SubjectId))
import Kikan.En.Action
  ( ActionProblem (..),
    ActionProofError (..),
    ActionSchemaHash,
    AuthorizeActionError (..),
    AuthorizeActionRequest (..),
    AuthorizedAction (..),
    Denial (..),
    IssuedActionProof (..),
    ShomeiAccessToken,
    actionObjectId,
    actionObjectType,
    actionOperation,
    actionResource,
    actionSchemaHashText,
    actionValueErrorText,
    agentPrincipalText,
    consistencyTokenText,
    decisionProofText,
    mkActionSchemaHash,
    mkConsistencyToken,
    requestIdText,
    shomeiAccessTokenText,
  )
import Kikan.En.Action.Api (actionAuthorizationProxy)
import Network.HTTP.Types.Status (statusCode)
import Servant.Client (ClientEnv, ClientError (..), ClientM, client, runClientM)
import Servant.Client.Core.Response (responseBody, responseStatusCode)

data ActionProofVerifier = ActionProofVerifier
  { issuerKeys :: !IssuerKeySet,
    acceptedSchemaHashes :: !(Set ActionSchemaHash),
    revokedBlockIds :: !(Set ByteString -> IO Bool)
  }

data KikanEnClient = KikanEnClient
  { clientEnv :: !ClientEnv,
    proofVerifier :: !ActionProofVerifier
  }

newActionProofVerifier :: IssuerKeySet -> Set ActionSchemaHash -> (Set ByteString -> IO Bool) -> ActionProofVerifier
newActionProofVerifier issuerKeys acceptedSchemaHashes revokedBlockIds = ActionProofVerifier {issuerKeys, acceptedSchemaHashes, revokedBlockIds}

newKikanEnClient :: ClientEnv -> ActionProofVerifier -> KikanEnClient
newKikanEnClient clientEnv proofVerifier = KikanEnClient {clientEnv, proofVerifier}

authorizeWire :: Maybe Text -> AuthorizeActionRequest -> ClientM IssuedActionProof
authorizeWire = client actionAuthorizationProxy

authorizeAgentAction :: KikanEnClient -> ShomeiAccessToken -> AuthorizeActionRequest -> IO (Either AuthorizeActionError AuthorizedAction)
authorizeAgentAction clientConfig token request = do
  response <- runClientM (authorizeWire (Just ("Bearer " <> shomeiAccessTokenText token)) request) clientConfig.clientEnv
  case response of
    Left clientError -> pure (Left (fromClientError clientError))
    Right issued -> do
      now <- getCurrentTime
      first ActionProofRejected <$> verifyIssuedAction clientConfig.proofVerifier now request issued

verifyIssuedAction :: ActionProofVerifier -> UTCTime -> AuthorizeActionRequest -> IssuedActionProof -> IO (Either ActionProofError AuthorizedAction)
verifyIssuedAction verifier now request issued = do
  verified <- verifyGrant verifier.issuerKeys (encodeUtf8 (decisionProofText issued.proof)) verifyRequest
  pure (first fromVerifyError verified >>= validateMetadata)
  where
    verifyRequest =
      VerifyRequest
        { expectedSubject = SubjectId (ObjectRef (ObjectType "agent") (agentPrincipalText request.principal)),
          expectedAudience = Audience "shikigami",
          operation = RelationName (actionOperation request.action),
          resource = ObjectRef (ObjectType (actionObjectType request.action)) (actionObjectId request.action),
          serviceName = Audience "shikigami",
          acceptedSchemaHashes = Set.map (En.SchemaHash . actionSchemaHashText) verifier.acceptedSchemaHashes,
          now,
          revoked = const (pure False),
          revokedBlockIds = verifier.revokedBlockIds
        }

    validateMetadata verified = do
      let En.SchemaHash signedSchemaHash = verified.schemaHash
          En.ConsistencyToken signedCheckedAt = verified.consistencyToken
      schemaHash <- firstValue (mkActionSchemaHash signedSchemaHash)
      checkedAt <- firstValue (mkConsistencyToken signedCheckedAt)
      case verified.requestId of
        Just (RequestId signedRequestId) | signedRequestId == requestIdText request.requestId -> pure ()
        _ -> Left (ProofMetadataMismatch "signed request id does not match the authorization request")
      if signedCheckedAt /= consistencyTokenText issued.checkedAt
        then Left (ProofMetadataMismatch "response checkedAt does not match the signed consistency token")
        else pure ()
      if verified.expiresAt /= issued.expiresAt
        then
          Left
            ( ProofMetadataMismatch
                ( "response expiry "
                    <> Text.pack (show issued.expiresAt)
                    <> " does not match signed expiry "
                    <> Text.pack (show verified.expiresAt)
                )
            )
        else pure ()
      pure
        AuthorizedAction
          { principal = request.principal,
            action = request.action,
            resource = actionResource request.action,
            requestId = request.requestId,
            schemaHash,
            checkedAt,
            expiresAt = verified.expiresAt,
            proof = issued.proof
          }

    firstValue = either (Left . ProofMetadataMismatch . actionValueErrorText) Right

fromVerifyError :: EnBiscuitVerifyError -> ActionProofError
fromVerifyError = \case
  SignatureInvalid detail -> ProofSignatureInvalid detail
  MalformedGrant detail -> ProofMalformed detail
  Expired -> ProofExpired
  WrongSubject -> ProofWrongSubject
  WrongAudience -> ProofWrongAudience
  UnacceptedSchemaHash -> ProofUnacceptedSchemaHash
  OperationNotAuthorized -> ProofWrongOperation
  ResourceNotInScope -> ProofWrongResource
  Revoked -> ProofRevoked
  RestrictionFailed detail -> ProofRestrictionFailed detail

fromClientError :: ClientError -> AuthorizeActionError
fromClientError = \case
  FailureResponse _ response ->
    let httpStatus = statusCode (responseStatusCode response)
        fallback = ActionProblem {code = "invalid_error_response", title = "Authorization failed", status = httpStatus, detail = "authorization service returned an unreadable problem document", retryable = httpStatus >= 500}
        details = either (const fallback) id (Aeson.eitherDecode (responseBody response))
     in case httpStatus of
          400 -> ActionRequestInvalid details
          401 -> ActionAuthenticationFailed details
          403 -> ActionDenied (Denial details)
          _ -> ActionAuthorizationUnavailable details
  other ->
    ActionAuthorizationUnavailable
      ActionProblem
        { code = "authorization_transport_error",
          title = "Authorization unavailable",
          status = 503,
          detail = Text.pack (show other),
          retryable = True
        }

first :: (a -> b) -> Either a c -> Either b c
first convert = either (Left . convert) Right
