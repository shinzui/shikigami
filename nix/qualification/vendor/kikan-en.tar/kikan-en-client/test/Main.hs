module Main (main) where

import Auth.Biscuit (toPublic)
import Data.Generics.Labels ()
import Data.Set qualified as Set
import Data.Text qualified as Text
import Data.Text.Encoding (decodeUtf8)
import Data.Time (UTCTime, addUTCTime)
import En.Biscuit.Grant (Audience (..), EnGrant (..), RequestId (..))
import En.Biscuit.Keys (parseSigningKeyText, singleKey)
import En.Biscuit.Mint (MintConfig (..), MintedGrant (..), mintObjectGrantWithExpiry)
import En.Check (CheckDecision (Allowed))
import En.Revision (ConsistencyToken (..), SchemaHash (..))
import En.Schema (ObjectType (..), RelationName (..))
import En.Tuple (ObjectRef (..), Subject (SubjectId))
import Kikan.En.Action
import Kikan.En.Client (newActionProofVerifier, verifyIssuedAction)
import System.Exit (exitFailure)

main :: IO ()
main = do
  (keyId, secret) <- expectRight "signing key" (parseSigningKeyText signingKey)
  principal <- expectRight "principal" (mkAgentPrincipal "agent_01h000000000000000triage")
  otherPrincipal <- expectRight "other principal" (mkAgentPrincipal "agent_01h000000000000000review")
  requestId <- expectRight "request id" (mkRequestId "req-proof-matrix")
  tool <- expectRight "tool" (mkCapabilityToolTarget "repository.search" "v1" "query")
  otherTool <- expectRight "other tool" (mkCapabilityToolTarget "repository.search" "v1" "delete")
  workspace <- expectRight "workspace" (mkWorkspaceTarget "shinzui/kikan")
  schema <- expectRight "schema" (mkActionSchemaHash "schema-kikan-v1")
  otherSchema <- expectRight "other schema" (mkActionSchemaHash "schema-kikan-v2")
  let request = AuthorizeActionRequest {principal, action = InvokeCapabilityTool tool, requestId}
      publicKeys = singleKey keyId (toPublic secret)
      verifier = newActionProofVerifier publicKeys (Set.singleton schema) (const (pure False))
      expiry = addUTCTime 30 baseTime
      grant = actionGrant request "shikigami" "schema-kikan-v1" expiry
      config = MintConfig {issuerSecretKey = secret, issuerKeyId = keyId, defaultTtl = 30, now = pure baseTime}
  minted <- mintObjectGrantWithExpiry config expiry Allowed grant >>= either (failTest . show) pure
  issued <- issuedFromMint minted

  assertRight "exact proof verifies" =<< verifyIssuedAction verifier baseTime request issued
  assertLeft "wrong subject" ProofWrongSubject =<< verifyIssuedAction verifier baseTime (request {principal = otherPrincipal}) issued
  assertLeft "wrong operation" ProofWrongOperation =<< verifyIssuedAction verifier baseTime (request {action = ReadWorkspace workspace}) issued
  assertLeft "wrong resource" ProofWrongResource =<< verifyIssuedAction verifier baseTime (request {action = InvokeCapabilityTool otherTool}) issued
  assertLeft "wrong schema" ProofUnacceptedSchemaHash =<< verifyIssuedAction (newActionProofVerifier publicKeys (Set.singleton otherSchema) (const (pure False))) baseTime request issued
  assertLeft "expired" ProofExpired =<< verifyIssuedAction verifier expiry request issued
  assertLeft "revoked block id" ProofRevoked =<< verifyIssuedAction (newActionProofVerifier publicKeys (Set.singleton schema) (const (pure True))) baseTime request issued

  wrongAudience <- mintObjectGrantWithExpiry config expiry Allowed (actionGrant request "another-service" "schema-kikan-v1" expiry) >>= either (failTest . show) issuedFromMint
  assertLeft "wrong audience" ProofWrongAudience =<< verifyIssuedAction verifier baseTime request wrongAudience

  tamperedProof <- expectRight "tampered token" (mkDecisionProof (decisionProofText issued.proof <> "A"))
  assertMatches "tampered bytes" isSignatureError =<< verifyIssuedAction verifier baseTime request (issued {proof = tamperedProof})
  mismatchedToken <- expectRight "mismatched checkedAt" (mkConsistencyToken "different-snapshot")
  assertMatches "unsigned response metadata mismatch" isMetadataMismatch =<< verifyIssuedAction verifier baseTime request (issued {checkedAt = mismatchedToken})

  putStrLn "OK: exact action proof verifies; subject/operation/resource/audience/schema/expiry/bytes/revocation fail closed"

actionGrant :: AuthorizeActionRequest -> Text.Text -> Text.Text -> UTCTime -> EnGrant
actionGrant request audience schema expiry =
  EnGrant
    { subject = SubjectId (ObjectRef (ObjectType "agent") (agentPrincipalText request.principal)),
      permission = RelationName (actionOperation request.action),
      object = ObjectRef (ObjectType (actionObjectType request.action)) (actionObjectId request.action),
      consistencyToken = ConsistencyToken "snapshot-42",
      schemaHash = SchemaHash schema,
      expiresAt = expiry,
      audience = Audience audience,
      requestId = Just (RequestId (requestIdText request.requestId)),
      revocationId = Nothing
    }

issuedFromMint :: MintedGrant -> IO IssuedActionProof
issuedFromMint minted = do
  proof <- expectRight "proof" (mkDecisionProof (decodeUtf8 minted.token))
  checkedAt <- expectRight "checkedAt" (mkConsistencyToken "snapshot-42")
  pure IssuedActionProof {proof, expiresAt = minted.expiresAt, revocationIds = [], checkedAt}

assertRight :: (Show error) => String -> Either error value -> IO ()
assertRight _ (Right _) = pure ()
assertRight label (Left err) = failTest (label <> ": " <> show err)

assertLeft :: (Eq error, Show error, Show value) => String -> error -> Either error value -> IO ()
assertLeft _ expected (Left actual) | expected == actual = pure ()
assertLeft label expected actual = failTest (label <> ": expected Left " <> show expected <> ", got " <> show actual)

assertMatches :: (Show error, Show value) => String -> (error -> Bool) -> Either error value -> IO ()
assertMatches _ predicate (Left err) | predicate err = pure ()
assertMatches label _ actual = failTest (label <> ": unexpected " <> show actual)

isSignatureError :: ActionProofError -> Bool
isSignatureError ProofSignatureInvalid {} = True
isSignatureError _ = False

isMetadataMismatch :: ActionProofError -> Bool
isMetadataMismatch ProofMetadataMismatch {} = True
isMetadataMismatch _ = False

expectRight :: (Show error) => String -> Either error value -> IO value
expectRight _ (Right value) = pure value
expectRight label (Left err) = failTest (label <> ": " <> show err)

failTest :: String -> IO a
failTest message = putStrLn ("FAIL: " <> message) >> exitFailure

baseTime :: UTCTime
baseTime = read "2026-08-26 12:00:00 UTC"

signingKey :: Text.Text
signingKey = "1:a2c4ead323536b925f3488ee83e0888b79c2761405ca7c0c9a018c7c1905eecc"
