module Main (main) where

import Data.Aeson qualified as Aeson
import Data.ByteString.Lazy.Char8 qualified as ByteString
import Data.Text (Text)
import Data.Time (UTCTime)
import Kikan.En.Action
import System.Exit (exitFailure)

main :: IO ()
main = do
  principal <- expectRight "valid agent principal" (mkAgentPrincipal "agent_01h000000000000000triage")
  requestId <- expectRight "valid request id" (mkRequestId "req_01h00000000000000000000000")
  provider <- expectRight "valid capability provider" (mkCapabilityTarget "repository.search" "v1")
  tool <- expectRight "valid capability tool" (mkCapabilityToolTarget "repository.search" "v1" "query")
  workspace <- expectRight "valid workspace" (mkWorkspaceTarget "shinzui/kikan")
  kawa <- expectRight "valid kawa source" (mkKawaTarget "shinzui/shikigami")
  kizashi <- expectRight "valid kizashi recipient" (mkKizashiTarget "acct-9931")
  intention <- expectRight "valid intention" (mkIntentionTarget "intention_01h000000000000000000000")
  let autonomyContext = mkAutonomyContext ActAutonomy sampleTime
  danwa <- expectRight "valid danwa thread" (mkDanwaTarget "thread-77")
  channel <- expectRight "valid channel" (mkChannelTarget "zendesk" "ticket-4815")

  let actions =
        [ ConnectCapability provider,
          DiscoverCapabilityTools provider,
          InvokeCapabilityTool tool,
          ReadWorkspace workspace,
          WriteWorkspace workspace,
          ExecuteWorkspace workspace,
          DispatchKawa kawa,
          DispatchKizashi kizashi,
          ActOnIntention intention autonomyContext,
          AttachDanwa danwa,
          DispatchChannel channel
        ]
  mapM_ roundTrip actions
  assertEqual "principal round trip" (Right principal) (Aeson.eitherDecode (Aeson.encode principal))
  assertEqual "request id round trip" (Right requestId) (Aeson.eitherDecode (Aeson.encode requestId))

  assertCoordinates
    actions
    [ ("can_connect", "capability_provider:repository.search@v1"),
      ("can_discover", "capability_provider:repository.search@v1"),
      ("can_invoke", "capability_tool:repository.search@v1/query"),
      ("can_read", "workspace:shinzui/kikan"),
      ("can_write", "workspace:shinzui/kikan"),
      ("can_bash", "workspace:shinzui/kikan"),
      ("can_dispatch", "kawa_source:shinzui/shikigami"),
      ("can_dispatch", "kizashi_recipient:acct-9931"),
      ("can_act", "intention:intention_01h000000000000000000000"),
      ("can_dispatch", "danwa_thread:thread-77"),
      ("can_dispatch", "channel_egress:zendesk/ticket-4815")
    ]

  assertLeft "empty capability" (mkCapabilityId "")
  assertLeft "empty revision" (mkCapabilityRevision "")
  assertLeft "ambiguous revision separator" (mkCapabilityRevision "v1/next")
  assertLeft "ambiguous tool separator" (mkLogicalToolName "repo/query")
  assertLeft "empty workspace" (mkWorkspaceTarget "")
  assertLeft "ambiguous channel provider" (mkChannelTarget "slack/team" "C123")
  assertLeft "principal without agent prefix" (mkAgentPrincipal "service_01h00000000000000000000")
  assertLeft "principal with tuple separator" (mkAgentPrincipal "agent_bad#member")
  _ <- expectRight "En schema hash with algorithm prefix" (mkActionSchemaHash "sha256:abc123")

  assertDecodeFails
    "unknown action tag"
    "{\"action\":\"launch_missiles\",\"target\":{\"kind\":\"workspace\",\"workspace\":\"x\"}}"
  assertDecodeFails
    "mismatched action and target"
    "{\"action\":\"invoke_capability_tool\",\"target\":{\"kind\":\"capability_provider\",\"capability\":\"repository.search\",\"revision\":\"v1\"}}"

  putStrLn "OK: Kikan action contract validates, maps, and round-trips the closed vocabulary"

roundTrip :: AgentAction -> IO ()
roundTrip action =
  assertEqual
    ("action round trip: " <> show action)
    (Right action)
    (Aeson.eitherDecode (Aeson.encode action))

assertCoordinates :: [AgentAction] -> [(Text, Text)] -> IO ()
assertCoordinates actions expected =
  assertEqual
    "closed action operation/resource mapping"
    expected
    ((\action -> (actionOperation action, canonicalResourceText (actionResource action))) <$> actions)

assertDecodeFails :: String -> ByteString.ByteString -> IO ()
assertDecodeFails label encoded =
  case Aeson.eitherDecode @AgentAction encoded of
    Left _ -> pure ()
    Right value -> failTest (label <> ": unexpectedly decoded " <> show value)

assertLeft :: String -> Either error value -> IO ()
assertLeft _ (Left _) = pure ()
assertLeft label (Right _) = failTest (label <> ": expected Left")

expectRight :: (Show error) => String -> Either error value -> IO value
expectRight _ (Right value) = pure value
expectRight label (Left problem) = failTest (label <> ": " <> show problem)

assertEqual :: (Eq value, Show value) => String -> value -> value -> IO ()
assertEqual label expected actual
  | expected == actual = pure ()
  | otherwise = failTest (label <> "\nexpected: " <> show expected <> "\n but got: " <> show actual)

failTest :: String -> IO a
failTest message = do
  putStrLn ("FAIL: " <> message)
  exitFailure

sampleTime :: UTCTime
sampleTime = read "2026-08-26 00:00:00 UTC"
