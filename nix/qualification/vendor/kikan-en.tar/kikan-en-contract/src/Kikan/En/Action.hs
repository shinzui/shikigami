-- | Stable, dependency-light vocabulary for one Kikan agent action.
--
-- Callers cannot submit raw En permissions or object references. Smart
-- constructors validate every identifier before an 'AgentAction' can be built,
-- and the closed JSON action tag determines the only target kind it accepts.
module Kikan.En.Action
  ( ActionValueError,
    actionValueErrorText,
    AgentPrincipal,
    mkAgentPrincipal,
    agentPrincipalText,
    RequestId,
    mkRequestId,
    requestIdText,
    CapabilityId,
    mkCapabilityId,
    capabilityIdText,
    CapabilityRevision,
    mkCapabilityRevision,
    capabilityRevisionText,
    LogicalToolName,
    mkLogicalToolName,
    logicalToolNameText,
    CapabilityTarget,
    mkCapabilityTarget,
    capabilityTargetId,
    capabilityTargetRevision,
    CapabilityToolTarget,
    mkCapabilityToolTarget,
    capabilityToolCapability,
    capabilityToolRevision,
    capabilityToolName,
    WorkspaceTarget,
    mkWorkspaceTarget,
    workspaceTargetText,
    IntentionTarget,
    mkIntentionTarget,
    intentionTargetText,
    AutonomyLevel (..),
    AutonomyContext,
    mkAutonomyContext,
    requestedAutonomy,
    autonomyCurrentTime,
    KawaTarget,
    mkKawaTarget,
    kawaTargetText,
    KizashiTarget,
    mkKizashiTarget,
    kizashiTargetText,
    DanwaTarget,
    mkDanwaTarget,
    danwaTargetText,
    ChannelTarget,
    mkChannelTarget,
    channelProviderText,
    channelConversationText,
    SinkTarget (..),
    AgentAction (..),
    actionTag,
    actionOperation,
    actionObjectType,
    actionObjectId,
    CanonicalResource,
    canonicalResourceText,
    actionResource,
    AuthorizeActionRequest (..),
    DecisionProof,
    mkDecisionProof,
    decisionProofText,
    RevocationId,
    mkRevocationId,
    revocationIdText,
    ConsistencyToken,
    mkConsistencyToken,
    consistencyTokenText,
    ActionSchemaHash,
    mkActionSchemaHash,
    actionSchemaHashText,
    IssuedActionProof (..),
    AuthorizedAction (..),
    ShomeiAccessToken,
    mkShomeiAccessToken,
    shomeiAccessTokenText,
    ActionProblem (..),
    Denial (..),
    ActionProofError (..),
    AuthorizeActionError (..),
  )
where

import Data.Aeson (FromJSON (..), ToJSON (..), Value)
import Data.Aeson qualified as Aeson
import Data.Aeson.Types (Pair, Parser)
import Data.Char qualified as Char
import Data.Text (Text)
import Data.Text qualified as Text
import Data.Time (UTCTime)
import GHC.Generics (Generic)

newtype ActionValueError = ActionValueError Text
  deriving stock (Eq, Ord, Show, Generic)

actionValueErrorText :: ActionValueError -> Text
actionValueErrorText (ActionValueError value) = value

newtype AgentPrincipal = AgentPrincipal Text
  deriving stock (Eq, Ord, Show, Generic)

mkAgentPrincipal :: Text -> Either ActionValueError AgentPrincipal
mkAgentPrincipal value = do
  checked <- validateOpaque "agent principal" ":#" value
  if "agent_" `Text.isPrefixOf` checked && Text.length checked > Text.length ("agent_" :: Text)
    then Right (AgentPrincipal checked)
    else Left (ActionValueError "agent principal must start with agent_ and include an identifier")

agentPrincipalText :: AgentPrincipal -> Text
agentPrincipalText (AgentPrincipal value) = value

instance ToJSON AgentPrincipal where
  toJSON = Aeson.String . agentPrincipalText

instance FromJSON AgentPrincipal where
  parseJSON = parseSmartText "AgentPrincipal" mkAgentPrincipal

newtype RequestId = RequestId Text
  deriving stock (Eq, Ord, Show, Generic)

mkRequestId :: Text -> Either ActionValueError RequestId
mkRequestId = fmap RequestId . validateOpaque "request id" ":#/"

requestIdText :: RequestId -> Text
requestIdText (RequestId value) = value

instance ToJSON RequestId where
  toJSON = Aeson.String . requestIdText

instance FromJSON RequestId where
  parseJSON = parseSmartText "RequestId" mkRequestId

newtype CapabilityId = CapabilityId Text
  deriving stock (Eq, Ord, Show, Generic)

mkCapabilityId :: Text -> Either ActionValueError CapabilityId
mkCapabilityId value
  | Text.length value > maxIdentifierLength =
      Left (tooLong "capability id")
  | validStart && Text.all validRest remainder && not (".." `Text.isInfixOf` value) =
      Right (CapabilityId value)
  | otherwise =
      Left (ActionValueError "capability id must match [a-z][a-z0-9.-]* without consecutive dots")
  where
    (validStart, remainder) =
      case Text.uncons value of
        Nothing -> (False, "")
        Just (first, rest) -> (isAsciiLower first, rest)

    validRest character =
      isAsciiLower character
        || ('0' <= character && character <= '9')
        || character == '.'
        || character == '-'

    isAsciiLower character = 'a' <= character && character <= 'z'

capabilityIdText :: CapabilityId -> Text
capabilityIdText (CapabilityId value) = value

instance ToJSON CapabilityId where
  toJSON = Aeson.String . capabilityIdText

instance FromJSON CapabilityId where
  parseJSON = parseSmartText "CapabilityId" mkCapabilityId

newtype CapabilityRevision = CapabilityRevision Text
  deriving stock (Eq, Ord, Show, Generic)

mkCapabilityRevision :: Text -> Either ActionValueError CapabilityRevision
mkCapabilityRevision = fmap CapabilityRevision . validateOpaque "capability revision" "@/:#"

capabilityRevisionText :: CapabilityRevision -> Text
capabilityRevisionText (CapabilityRevision value) = value

instance ToJSON CapabilityRevision where
  toJSON = Aeson.String . capabilityRevisionText

instance FromJSON CapabilityRevision where
  parseJSON = parseSmartText "CapabilityRevision" mkCapabilityRevision

newtype LogicalToolName = LogicalToolName Text
  deriving stock (Eq, Ord, Show, Generic)

mkLogicalToolName :: Text -> Either ActionValueError LogicalToolName
mkLogicalToolName = fmap LogicalToolName . validateOpaque "logical tool name" "@/:#"

logicalToolNameText :: LogicalToolName -> Text
logicalToolNameText (LogicalToolName value) = value

instance ToJSON LogicalToolName where
  toJSON = Aeson.String . logicalToolNameText

instance FromJSON LogicalToolName where
  parseJSON = parseSmartText "LogicalToolName" mkLogicalToolName

data CapabilityTarget = CapabilityTarget !CapabilityId !CapabilityRevision
  deriving stock (Eq, Ord, Show, Generic)

mkCapabilityTarget :: Text -> Text -> Either ActionValueError CapabilityTarget
mkCapabilityTarget capability revision =
  CapabilityTarget <$> mkCapabilityId capability <*> mkCapabilityRevision revision

capabilityTargetId :: CapabilityTarget -> CapabilityId
capabilityTargetId (CapabilityTarget capability _) = capability

capabilityTargetRevision :: CapabilityTarget -> CapabilityRevision
capabilityTargetRevision (CapabilityTarget _ revision) = revision

instance ToJSON CapabilityTarget where
  toJSON target =
    targetObject
      "capability_provider"
      [ "capability" Aeson..= capabilityTargetId target,
        "revision" Aeson..= capabilityTargetRevision target
      ]

instance FromJSON CapabilityTarget where
  parseJSON = Aeson.withObject "CapabilityTarget" \value -> do
    requireKind "capability_provider" value
    CapabilityTarget <$> value Aeson..: "capability" <*> value Aeson..: "revision"

data CapabilityToolTarget = CapabilityToolTarget !CapabilityId !CapabilityRevision !LogicalToolName
  deriving stock (Eq, Ord, Show, Generic)

mkCapabilityToolTarget :: Text -> Text -> Text -> Either ActionValueError CapabilityToolTarget
mkCapabilityToolTarget capability revision name =
  CapabilityToolTarget
    <$> mkCapabilityId capability
    <*> mkCapabilityRevision revision
    <*> mkLogicalToolName name

capabilityToolCapability :: CapabilityToolTarget -> CapabilityId
capabilityToolCapability (CapabilityToolTarget capability _ _) = capability

capabilityToolRevision :: CapabilityToolTarget -> CapabilityRevision
capabilityToolRevision (CapabilityToolTarget _ revision _) = revision

capabilityToolName :: CapabilityToolTarget -> LogicalToolName
capabilityToolName (CapabilityToolTarget _ _ name) = name

instance ToJSON CapabilityToolTarget where
  toJSON target =
    targetObject
      "capability_tool"
      [ "capability" Aeson..= capabilityToolCapability target,
        "revision" Aeson..= capabilityToolRevision target,
        "tool" Aeson..= capabilityToolName target
      ]

instance FromJSON CapabilityToolTarget where
  parseJSON = Aeson.withObject "CapabilityToolTarget" \value -> do
    requireKind "capability_tool" value
    CapabilityToolTarget
      <$> value Aeson..: "capability"
      <*> value Aeson..: "revision"
      <*> value Aeson..: "tool"

newtype WorkspaceTarget = WorkspaceTarget Text
  deriving stock (Eq, Ord, Show, Generic)

mkWorkspaceTarget :: Text -> Either ActionValueError WorkspaceTarget
mkWorkspaceTarget = fmap WorkspaceTarget . validateOpaque "workspace target" ":#"

workspaceTargetText :: WorkspaceTarget -> Text
workspaceTargetText (WorkspaceTarget value) = value

instance ToJSON WorkspaceTarget where
  toJSON target = targetObject "workspace" ["workspace" Aeson..= workspaceTargetText target]

instance FromJSON WorkspaceTarget where
  parseJSON = Aeson.withObject "WorkspaceTarget" \value -> do
    requireKind "workspace" value
    raw <- value Aeson..: "workspace"
    either (fail . Text.unpack . actionValueErrorText) pure (mkWorkspaceTarget raw)

newtype IntentionTarget = IntentionTarget Text
  deriving stock (Eq, Ord, Show, Generic)

mkIntentionTarget :: Text -> Either ActionValueError IntentionTarget
mkIntentionTarget = fmap IntentionTarget . validateOpaque "intention target" ":#/"

intentionTargetText :: IntentionTarget -> Text
intentionTargetText (IntentionTarget value) = value

instance ToJSON IntentionTarget where
  toJSON target = targetObject "intention" ["intention" Aeson..= intentionTargetText target]

instance FromJSON IntentionTarget where
  parseJSON = Aeson.withObject "IntentionTarget" \value -> do
    requireKind "intention" value
    raw <- value Aeson..: "intention"
    either (fail . Text.unpack . actionValueErrorText) pure (mkIntentionTarget raw)

-- | The autonomy requested for an intention delegation. The schema deliberately
-- admits only the two levels an agent may request; @admin@ is a grant ceiling,
-- never a caller request.
data AutonomyLevel = ReadAutonomy | ActAutonomy
  deriving stock (Eq, Ord, Show, Generic)

instance ToJSON AutonomyLevel where
  toJSON ReadAutonomy = Aeson.String "read"
  toJSON ActAutonomy = Aeson.String "act"

instance FromJSON AutonomyLevel where
  parseJSON = Aeson.withText "AutonomyLevel" \case
    "read" -> pure ReadAutonomy
    "act" -> pure ActAutonomy
    other -> fail ("unknown requested autonomy: " <> Text.unpack other)

data AutonomyContext = AutonomyContext !AutonomyLevel !UTCTime
  deriving stock (Eq, Ord, Show, Generic)

mkAutonomyContext :: AutonomyLevel -> UTCTime -> AutonomyContext
mkAutonomyContext = AutonomyContext

requestedAutonomy :: AutonomyContext -> AutonomyLevel
requestedAutonomy (AutonomyContext level _) = level

autonomyCurrentTime :: AutonomyContext -> UTCTime
autonomyCurrentTime (AutonomyContext _ currentTime) = currentTime

instance ToJSON AutonomyContext where
  toJSON context =
    Aeson.object
      [ "requestedAutonomy" Aeson..= requestedAutonomy context,
        "currentTime" Aeson..= autonomyCurrentTime context
      ]

instance FromJSON AutonomyContext where
  parseJSON = Aeson.withObject "AutonomyContext" \value ->
    AutonomyContext <$> value Aeson..: "requestedAutonomy" <*> value Aeson..: "currentTime"

newtype KawaTarget = KawaTarget Text
  deriving stock (Eq, Ord, Show, Generic)

mkKawaTarget :: Text -> Either ActionValueError KawaTarget
mkKawaTarget = fmap KawaTarget . validateOpaque "kawa source" ":#"

kawaTargetText :: KawaTarget -> Text
kawaTargetText (KawaTarget value) = value

instance ToJSON KawaTarget where
  toJSON target = targetObject "kawa_source" ["source" Aeson..= kawaTargetText target]

instance FromJSON KawaTarget where
  parseJSON = Aeson.withObject "KawaTarget" \value -> do
    requireKind "kawa_source" value
    raw <- value Aeson..: "source"
    either (fail . Text.unpack . actionValueErrorText) pure (mkKawaTarget raw)

newtype KizashiTarget = KizashiTarget Text
  deriving stock (Eq, Ord, Show, Generic)

mkKizashiTarget :: Text -> Either ActionValueError KizashiTarget
mkKizashiTarget = fmap KizashiTarget . validateOpaque "kizashi recipient" ":#"

kizashiTargetText :: KizashiTarget -> Text
kizashiTargetText (KizashiTarget value) = value

instance ToJSON KizashiTarget where
  toJSON target = targetObject "kizashi_recipient" ["recipient" Aeson..= kizashiTargetText target]

instance FromJSON KizashiTarget where
  parseJSON = Aeson.withObject "KizashiTarget" \value -> do
    requireKind "kizashi_recipient" value
    raw <- value Aeson..: "recipient"
    either (fail . Text.unpack . actionValueErrorText) pure (mkKizashiTarget raw)

newtype DanwaTarget = DanwaTarget Text
  deriving stock (Eq, Ord, Show, Generic)

mkDanwaTarget :: Text -> Either ActionValueError DanwaTarget
mkDanwaTarget = fmap DanwaTarget . validateOpaque "danwa thread" ":#"

danwaTargetText :: DanwaTarget -> Text
danwaTargetText (DanwaTarget value) = value

instance ToJSON DanwaTarget where
  toJSON target = targetObject "danwa_thread" ["thread" Aeson..= danwaTargetText target]

instance FromJSON DanwaTarget where
  parseJSON = Aeson.withObject "DanwaTarget" \value -> do
    requireKind "danwa_thread" value
    raw <- value Aeson..: "thread"
    either (fail . Text.unpack . actionValueErrorText) pure (mkDanwaTarget raw)

data ChannelTarget = ChannelTarget !Text !Text
  deriving stock (Eq, Ord, Show, Generic)

mkChannelTarget :: Text -> Text -> Either ActionValueError ChannelTarget
mkChannelTarget provider conversation =
  ChannelTarget
    <$> validateOpaque "channel provider" ":#/" provider
    <*> validateOpaque "channel conversation key" ":#/" conversation

channelProviderText :: ChannelTarget -> Text
channelProviderText (ChannelTarget provider _) = provider

channelConversationText :: ChannelTarget -> Text
channelConversationText (ChannelTarget _ conversation) = conversation

instance ToJSON ChannelTarget where
  toJSON target =
    targetObject
      "channel_egress"
      [ "provider" Aeson..= channelProviderText target,
        "conversation" Aeson..= channelConversationText target
      ]

instance FromJSON ChannelTarget where
  parseJSON = Aeson.withObject "ChannelTarget" \value -> do
    requireKind "channel_egress" value
    provider <- value Aeson..: "provider"
    conversation <- value Aeson..: "conversation"
    either (fail . Text.unpack . actionValueErrorText) pure (mkChannelTarget provider conversation)

data SinkTarget
  = KawaSink !KawaTarget
  | KizashiSink !KizashiTarget
  | DanwaSink !DanwaTarget
  | ChannelSink !ChannelTarget
  deriving stock (Eq, Ord, Show, Generic)

instance ToJSON SinkTarget where
  toJSON = \case
    KawaSink target -> toJSON target
    KizashiSink target -> toJSON target
    DanwaSink target -> toJSON target
    ChannelSink target -> toJSON target

instance FromJSON SinkTarget where
  parseJSON raw = Aeson.withObject "SinkTarget" parseTarget raw
    where
      parseTarget value = do
        kind <- value Aeson..: "kind"
        case kind :: Text of
          "kawa_source" -> KawaSink <$> parseJSON raw
          "kizashi_recipient" -> KizashiSink <$> parseJSON raw
          "danwa_thread" -> DanwaSink <$> parseJSON raw
          "channel_egress" -> ChannelSink <$> parseJSON raw
          other -> fail ("unknown sink target kind: " <> Text.unpack other)

data AgentAction
  = ConnectCapability !CapabilityTarget
  | DiscoverCapabilityTools !CapabilityTarget
  | InvokeCapabilityTool !CapabilityToolTarget
  | ReadWorkspace !WorkspaceTarget
  | WriteWorkspace !WorkspaceTarget
  | ExecuteWorkspace !WorkspaceTarget
  | DispatchKawa !KawaTarget
  | DispatchKizashi !KizashiTarget
  | ActOnIntention !IntentionTarget !AutonomyContext
  | AttachDanwa !DanwaTarget
  | DispatchChannel !ChannelTarget
  deriving stock (Eq, Ord, Show, Generic)

actionTag :: AgentAction -> Text
actionTag = \case
  ConnectCapability {} -> "connect_capability"
  DiscoverCapabilityTools {} -> "discover_capability_tools"
  InvokeCapabilityTool {} -> "invoke_capability_tool"
  ReadWorkspace {} -> "read_workspace"
  WriteWorkspace {} -> "write_workspace"
  ExecuteWorkspace {} -> "execute_workspace"
  DispatchKawa {} -> "dispatch_kawa"
  DispatchKizashi {} -> "dispatch_kizashi"
  ActOnIntention {} -> "act_on_intention"
  AttachDanwa {} -> "attach_danwa"
  DispatchChannel {} -> "dispatch_channel"

actionOperation :: AgentAction -> Text
actionOperation = \case
  ConnectCapability {} -> "can_connect"
  DiscoverCapabilityTools {} -> "can_discover"
  InvokeCapabilityTool {} -> "can_invoke"
  ReadWorkspace {} -> "can_read"
  WriteWorkspace {} -> "can_write"
  ExecuteWorkspace {} -> "can_bash"
  DispatchKawa {} -> "can_dispatch"
  DispatchKizashi {} -> "can_dispatch"
  ActOnIntention {} -> "can_act"
  AttachDanwa {} -> "can_dispatch"
  DispatchChannel {} -> "can_dispatch"

actionObjectType :: AgentAction -> Text
actionObjectType = \case
  ConnectCapability {} -> "capability_provider"
  DiscoverCapabilityTools {} -> "capability_provider"
  InvokeCapabilityTool {} -> "capability_tool"
  ReadWorkspace {} -> "workspace"
  WriteWorkspace {} -> "workspace"
  ExecuteWorkspace {} -> "workspace"
  DispatchKawa {} -> "kawa_source"
  DispatchKizashi {} -> "kizashi_recipient"
  ActOnIntention {} -> "intention"
  AttachDanwa {} -> "danwa_thread"
  DispatchChannel {} -> "channel_egress"

actionObjectId :: AgentAction -> Text
actionObjectId = \case
  ConnectCapability target -> providerObjectId target
  DiscoverCapabilityTools target -> providerObjectId target
  InvokeCapabilityTool target -> toolObjectId target
  ReadWorkspace target -> workspaceTargetText target
  WriteWorkspace target -> workspaceTargetText target
  ExecuteWorkspace target -> workspaceTargetText target
  DispatchKawa target -> kawaTargetText target
  DispatchKizashi target -> kizashiTargetText target
  ActOnIntention target _ -> intentionTargetText target
  AttachDanwa target -> danwaTargetText target
  DispatchChannel target -> channelProviderText target <> "/" <> channelConversationText target

newtype CanonicalResource = CanonicalResource Text
  deriving stock (Eq, Ord, Show, Generic)

canonicalResourceText :: CanonicalResource -> Text
canonicalResourceText (CanonicalResource value) = value

actionResource :: AgentAction -> CanonicalResource
actionResource action =
  CanonicalResource (actionObjectType action <> ":" <> actionObjectId action)

instance ToJSON CanonicalResource where
  toJSON = Aeson.String . canonicalResourceText

instance FromJSON CanonicalResource where
  parseJSON = Aeson.withText "CanonicalResource" \value ->
    if Text.null value
      then fail "canonical resource must not be empty"
      else pure (CanonicalResource value)

instance ToJSON AgentAction where
  toJSON action =
    Aeson.object
      ( [ "action" Aeson..= actionTag action,
          "target" Aeson..= actionTargetJson action
        ]
          <> case action of
            ActOnIntention _ context -> ["context" Aeson..= context]
            _ -> []
      )

instance FromJSON AgentAction where
  parseJSON = Aeson.withObject "AgentAction" \value -> do
    tag <- value Aeson..: "action"
    target <- value Aeson..: "target"
    case tag :: Text of
      "connect_capability" -> ConnectCapability <$> parseJSON target
      "discover_capability_tools" -> DiscoverCapabilityTools <$> parseJSON target
      "invoke_capability_tool" -> InvokeCapabilityTool <$> parseJSON target
      "read_workspace" -> ReadWorkspace <$> parseJSON target
      "write_workspace" -> WriteWorkspace <$> parseJSON target
      "execute_workspace" -> ExecuteWorkspace <$> parseJSON target
      "dispatch_kawa" -> DispatchKawa <$> parseJSON target
      "dispatch_kizashi" -> DispatchKizashi <$> parseJSON target
      "act_on_intention" -> ActOnIntention <$> parseJSON target <*> value Aeson..: "context"
      "attach_danwa" -> AttachDanwa <$> parseJSON target
      "dispatch_channel" -> DispatchChannel <$> parseJSON target
      other -> fail ("unknown agent action: " <> Text.unpack other)

actionTargetJson :: AgentAction -> Value
actionTargetJson = \case
  ConnectCapability target -> toJSON target
  DiscoverCapabilityTools target -> toJSON target
  InvokeCapabilityTool target -> toJSON target
  ReadWorkspace target -> toJSON target
  WriteWorkspace target -> toJSON target
  ExecuteWorkspace target -> toJSON target
  DispatchKawa target -> toJSON target
  DispatchKizashi target -> toJSON target
  ActOnIntention target _ -> toJSON target
  AttachDanwa target -> toJSON target
  DispatchChannel target -> toJSON target

providerObjectId :: CapabilityTarget -> Text
providerObjectId target =
  capabilityIdText (capabilityTargetId target)
    <> "@"
    <> capabilityRevisionText (capabilityTargetRevision target)

toolObjectId :: CapabilityToolTarget -> Text
toolObjectId target =
  capabilityIdText (capabilityToolCapability target)
    <> "@"
    <> capabilityRevisionText (capabilityToolRevision target)
    <> "/"
    <> logicalToolNameText (capabilityToolName target)

targetObject :: Text -> [Pair] -> Value
targetObject kind fields =
  Aeson.object (("kind" Aeson..= kind) : fields)

requireKind :: Text -> Aeson.Object -> Parser ()
requireKind expected value = do
  actual <- value Aeson..: "kind"
  if actual == expected
    then pure ()
    else fail ("expected target kind " <> Text.unpack expected <> ", got " <> Text.unpack actual)

parseSmartText :: Text -> (Text -> Either ActionValueError a) -> Value -> Parser a
parseSmartText label constructor =
  Aeson.withText (Text.unpack label) (either (fail . Text.unpack . actionValueErrorText) pure . constructor)

validateOpaque :: Text -> Text -> Text -> Either ActionValueError Text
validateOpaque label reserved value
  | Text.null value = Left (ActionValueError (label <> " must not be empty"))
  | Text.length value > maxIdentifierLength = Left (tooLong label)
  | Just offending <- Text.find (\character -> Char.isSpace character || Char.isControl character) value =
      Left (ActionValueError (label <> " must not contain whitespace or control characters: " <> Text.pack (show offending)))
  | Just offending <- Text.find (`Text.elem` reserved) value =
      Left (ActionValueError (label <> " must not contain " <> Text.singleton offending))
  | otherwise = Right value

tooLong :: Text -> ActionValueError
tooLong label =
  ActionValueError (label <> " must be at most " <> Text.pack (show maxIdentifierLength) <> " characters")

maxIdentifierLength :: Int
maxIdentifierLength = 128

data AuthorizeActionRequest = AuthorizeActionRequest
  { principal :: !AgentPrincipal,
    action :: !AgentAction,
    requestId :: !RequestId
  }
  deriving stock (Eq, Show, Generic)
  deriving anyclass (FromJSON, ToJSON)

newtype DecisionProof = DecisionProof Text
  deriving stock (Eq, Ord, Show, Generic)
  deriving newtype (FromJSON, ToJSON)

decisionProofText :: DecisionProof -> Text
decisionProofText (DecisionProof value) = value

mkDecisionProof :: Text -> Either ActionValueError DecisionProof
mkDecisionProof value
  | Text.null value = Left (ActionValueError "decision proof must not be empty")
  | Text.length value > 65536 = Left (ActionValueError "decision proof exceeds 65536 characters")
  | Text.any Char.isSpace value = Left (ActionValueError "decision proof must not contain whitespace")
  | otherwise = Right (DecisionProof value)

newtype RevocationId = RevocationId Text
  deriving stock (Eq, Ord, Show, Generic)
  deriving newtype (FromJSON, ToJSON)

revocationIdText :: RevocationId -> Text
revocationIdText (RevocationId value) = value

mkRevocationId :: Text -> Either ActionValueError RevocationId
mkRevocationId = fmap RevocationId . validateOpaque "revocation id" ":#/"

newtype ConsistencyToken = ConsistencyToken Text
  deriving stock (Eq, Ord, Show, Generic)
  deriving newtype (FromJSON, ToJSON)

consistencyTokenText :: ConsistencyToken -> Text
consistencyTokenText (ConsistencyToken value) = value

mkConsistencyToken :: Text -> Either ActionValueError ConsistencyToken
mkConsistencyToken = fmap ConsistencyToken . validateOpaque "consistency token" ""

newtype ActionSchemaHash = ActionSchemaHash Text
  deriving stock (Eq, Ord, Show, Generic)
  deriving newtype (FromJSON, ToJSON)

actionSchemaHashText :: ActionSchemaHash -> Text
actionSchemaHashText (ActionSchemaHash value) = value

mkActionSchemaHash :: Text -> Either ActionValueError ActionSchemaHash
mkActionSchemaHash = fmap ActionSchemaHash . validateOpaque "schema hash" "#/"

data IssuedActionProof = IssuedActionProof
  { proof :: !DecisionProof,
    expiresAt :: !UTCTime,
    revocationIds :: ![RevocationId],
    checkedAt :: !ConsistencyToken
  }
  deriving stock (Eq, Show, Generic)
  deriving anyclass (FromJSON, ToJSON)

data AuthorizedAction = AuthorizedAction
  { principal :: !AgentPrincipal,
    action :: !AgentAction,
    resource :: !CanonicalResource,
    requestId :: !RequestId,
    schemaHash :: !ActionSchemaHash,
    checkedAt :: !ConsistencyToken,
    expiresAt :: !UTCTime,
    proof :: !DecisionProof
  }
  deriving stock (Eq, Show, Generic)
  deriving anyclass (FromJSON, ToJSON)

newtype ShomeiAccessToken = ShomeiAccessToken Text
  deriving stock (Eq, Ord, Generic)

instance Show ShomeiAccessToken where
  show _ = "ShomeiAccessToken <redacted>"

mkShomeiAccessToken :: Text -> Either ActionValueError ShomeiAccessToken
mkShomeiAccessToken value
  | Text.null (Text.strip value) = Left (ActionValueError "Shomei access token must not be empty")
  | otherwise = Right (ShomeiAccessToken value)

shomeiAccessTokenText :: ShomeiAccessToken -> Text
shomeiAccessTokenText (ShomeiAccessToken value) = value

data ActionProblem = ActionProblem
  { code :: !Text,
    title :: !Text,
    status :: !Int,
    detail :: !Text,
    retryable :: !Bool
  }
  deriving stock (Eq, Show, Generic)
  deriving anyclass (FromJSON, ToJSON)

newtype Denial = Denial {problem :: ActionProblem}
  deriving stock (Eq, Show, Generic)
  deriving anyclass (FromJSON, ToJSON)

data AuthorizeActionError
  = ActionDenied !Denial
  | ActionRequestInvalid !ActionProblem
  | ActionAuthenticationFailed !ActionProblem
  | ActionProofRejected !ActionProofError
  | ActionAuthorizationUnavailable !ActionProblem
  deriving stock (Eq, Show, Generic)
  deriving anyclass (FromJSON, ToJSON)

data ActionProofError
  = ProofSignatureInvalid !Text
  | ProofMalformed !Text
  | ProofExpired
  | ProofWrongSubject
  | ProofWrongAudience
  | ProofUnacceptedSchemaHash
  | ProofWrongOperation
  | ProofWrongResource
  | ProofRevoked
  | ProofRestrictionFailed !Text
  | ProofMetadataMismatch !Text
  deriving stock (Eq, Show, Generic)
  deriving anyclass (FromJSON, ToJSON)
