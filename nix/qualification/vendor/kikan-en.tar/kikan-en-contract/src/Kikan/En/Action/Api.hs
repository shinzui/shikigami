{-# LANGUAGE DataKinds #-}
{-# LANGUAGE TypeOperators #-}

-- | The public action-authorization route shared by the Kikan host and client.
-- The bearer header is optional at the routing layer so the handler can return
-- the same typed RFC 9457-shaped problem body for a missing or invalid token.
module Kikan.En.Action.Api
  ( ActionAuthorizationAPI,
    actionAuthorizationProxy,
  )
where

import Data.Proxy (Proxy (..))
import Data.Text (Text)
import Kikan.En.Action (AuthorizeActionRequest, IssuedActionProof)
import Servant.API (Header, JSON, Post, ReqBody, type (:>))

type ActionAuthorizationAPI =
  "v1"
    :> "agent-actions"
    :> "authorize"
    :> Header "Authorization" Text
    :> ReqBody '[JSON] AuthorizeActionRequest
    :> Post '[JSON] IssuedActionProof

actionAuthorizationProxy :: Proxy ActionAuthorizationAPI
actionAuthorizationProxy = Proxy
